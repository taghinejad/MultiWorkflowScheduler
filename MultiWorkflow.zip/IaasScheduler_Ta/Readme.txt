Need JRE 1.7



-Version 2.1
Inserted Multi-workflow with Different deadlines. 


-Version 2.2 
Inserting Uncertain Task scheduling from utility.configuration
 -Algorithms updated
	-HEFT Multi-workflow 
	-PCP multi-workflow algorithm
	
	
  -Algorithms created
	-NOSF is implemented
	-ECTD which  my algorithm is implemented. 
	
  
